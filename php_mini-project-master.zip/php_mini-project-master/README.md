# php_mini-project
college pleacement cell project using php,MySQL
